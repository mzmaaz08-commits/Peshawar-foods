import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
  updateProfile
} from 'firebase/auth'
import {
  collection,
  addDoc,
  getDocs,
  getDoc,
  doc,
  query,
  where,
  orderBy,
  serverTimestamp
} from 'firebase/firestore'
import { ref, uploadBytesResumable, getDownloadURL } from 'firebase/storage'
import { auth, db, storage } from './config'

// ============ AUTHENTICATION SERVICES ============

/**
 * Register a new user with email and password
 * @param {string} email - User's email
 * @param {string} password - User's password
 * @param {string} name - User's full name
 * @returns {Promise<object>} - User credential
 */
export const registerUser = async (email, password, name) => {
  try {
    const userCredential = await createUserWithEmailAndPassword(auth, email, password)
    const user = userCredential.user

    // Update user profile with display name
    await updateProfile(user, {
      displayName: name
    })

    // Create user document in Firestore
    await addDoc(collection(db, 'users'), {
      uid: user.uid,
      name: name,
      email: email,
      role: 'customer',
      favoriteRestaurants: [],
      createdAt: serverTimestamp()
    })

    return {
      success: true,
      user: {
        uid: user.uid,
        email: user.email,
        displayName: name
      }
    }
  } catch (error) {
    return {
      success: false,
      error: error.message
    }
  }
}

/**
 * Login user with email and password
 * @param {string} email - User's email
 * @param {string} password - User's password
 * @returns {Promise<object>} - Login result
 */
export const loginUser = async (email, password) => {
  try {
    const userCredential = await signInWithEmailAndPassword(auth, email, password)
    const user = userCredential.user

    return {
      success: true,
      user: {
        uid: user.uid,
        email: user.email,
        displayName: user.displayName
      }
    }
  } catch (error) {
    return {
      success: false,
      error: error.message
    }
  }
}

/**
 * Logout current user
 * @returns {Promise<object>} - Logout result
 */
export const logoutUser = async () => {
  try {
    await signOut(auth)
    return { success: true }
  } catch (error) {
    return {
      success: false,
      error: error.message
    }
  }
}

/**
 * Listen for auth state changes
 * @param {function} callback - Callback function with user
 * @returns {function} - Unsubscribe function
 */
export const onAuthChange = (callback) => {
  return onAuthStateChanged(auth, (user) => {
    callback(user)
  })
}

/**
 * Get current user
 * @returns {object|null} - Current user or null
 */
export const getCurrentUser = () => {
  return auth.currentUser
}

// ============ RESTAURANT SERVICES ============

/**
 * Register a new restaurant in Firestore
 * @param {object} restaurantData - Restaurant data
 * @param {string} ownerId - Owner's user ID
 * @returns {Promise<object>} - Result with restaurant ID
 */
export const registerRestaurant = async (restaurantData, ownerId) => {
  try {
    const docRef = await addDoc(collection(db, 'restaurants'), {
      ...restaurantData,
      ownerId: ownerId,
      rating: 0,
      totalReviews: 0,
      isActive: true,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp()
    })

    // Update user document to set role as owner and link restaurant
    const userQuery = query(collection(db, 'users'), where('uid', '==', ownerId))
    const userSnapshot = await getDocs(userQuery)

    if (!userSnapshot.empty) {
      const userDoc = userSnapshot.docs[0]
      // We'll update this in a separate function if needed
    }

    return {
      success: true,
      restaurantId: docRef.id
    }
  } catch (error) {
    return {
      success: false,
      error: error.message
    }
  }
}

/**
 * Get all restaurants
 * @returns {Promise<object>} - List of restaurants
 */
export const getAllRestaurants = async () => {
  try {
    const q = query(collection(db, 'restaurants'), orderBy('createdAt', 'desc'))
    const querySnapshot = await getDocs(q)
    const restaurants = []

    querySnapshot.forEach((doc) => {
      restaurants.push({
        id: doc.id,
        ...doc.data()
      })
    })

    return {
      success: true,
      restaurants
    }
  } catch (error) {
    return {
      success: false,
      error: error.message,
      restaurants: []
    }
  }
}

/**
 * Get a single restaurant by ID
 * @param {string} restaurantId - Restaurant ID
 * @returns {Promise<object>} - Restaurant data
 */
export const getRestaurantById = async (restaurantId) => {
  try {
    const docSnap = await getDoc(doc(db, 'restaurants', restaurantId))

    if (docSnap.exists()) {
      return {
        success: true,
        restaurant: {
          id: docSnap.id,
          ...docSnap.data()
        }
      }
    } else {
      return {
        success: false,
        error: 'Restaurant not found'
      }
    }
  } catch (error) {
    return {
      success: false,
      error: error.message
    }
  }
}

/**
 * Get restaurants owned by a specific user
 * @param {string} ownerId - Owner's user ID
 * @returns {Promise<object>} - List of restaurants
 */
export const getRestaurantsByOwner = async (ownerId) => {
  try {
    const q = query(
      collection(db, 'restaurants'),
      where('ownerId', '==', ownerId)
    )
    const querySnapshot = await getDocs(q)
    const restaurants = []

    querySnapshot.forEach((doc) => {
      restaurants.push({
        id: doc.id,
        ...doc.data()
      })
    })

    return {
      success: true,
      restaurants
    }
  } catch (error) {
    return {
      success: false,
      error: error.message,
      restaurants: []
    }
  }
}

// ============ DISH SERVICES ============

/**
 * Add a new dish to a restaurant
 * @param {object} dishData - Dish data
 * @param {string} restaurantId - Restaurant ID
 * @returns {Promise<object>} - Result with dish ID
 */
export const addDish = async (dishData, restaurantId) => {
  try {
    const docRef = await addDoc(collection(db, 'dishes'), {
      ...dishData,
      restaurantId: restaurantId,
      isAvailable: true,
      isSpecial: false,
      createdAt: serverTimestamp()
    })

    return {
      success: true,
      dishId: docRef.id
    }
  } catch (error) {
    return {
      success: false,
      error: error.message
    }
  }
}

/**
 * Get all dishes for a restaurant
 * @param {string} restaurantId - Restaurant ID
 * @returns {Promise<object>} - List of dishes
 */
export const getDishesByRestaurant = async (restaurantId) => {
  try {
    const q = query(
      collection(db, 'dishes'),
      where('restaurantId', '==', restaurantId)
    )
    const querySnapshot = await getDocs(q)
    const dishes = []

    querySnapshot.forEach((doc) => {
      dishes.push({
        id: doc.id,
        ...doc.data()
      })
    })

    return {
      success: true,
      dishes
    }
  } catch (error) {
    return {
      success: false,
      error: error.message,
      dishes: []
    }
  }
}

// ============ REVIEW SERVICES ============

/**
 * Add a review for a restaurant
 * @param {object} reviewData - Review data
 * @returns {Promise<object>} - Result with review ID
 */
export const addReview = async (reviewData) => {
  try {
    const docRef = await addDoc(collection(db, 'reviews'), {
      ...reviewData,
      createdAt: serverTimestamp()
    })

    return {
      success: true,
      reviewId: docRef.id
    }
  } catch (error) {
    return {
      success: false,
      error: error.message
    }
  }
}

/**
 * Get all reviews for a restaurant
 * @param {string} restaurantId - Restaurant ID
 * @returns {Promise<object>} - List of reviews
 */
export const getReviewsByRestaurant = async (restaurantId) => {
  try {
    const q = query(
      collection(db, 'reviews'),
      where('restaurantId', '==', restaurantId),
      orderBy('createdAt', 'desc')
    )
    const querySnapshot = await getDocs(q)
    const reviews = []

    querySnapshot.forEach((doc) => {
      reviews.push({
        id: doc.id,
        ...doc.data()
      })
    })

    return {
      success: true,
      reviews
    }
  } catch (error) {
    return {
      success: false,
      error: error.message,
      reviews: []
    }
  }
}

// ============ STORAGE SERVICES ============

/**
 * Upload an image to Firebase Storage
 * @param {File} file - Image file
 * @param {string} path - Storage path (e.g., 'restaurants/restaurantId/image.jpg')
 * @returns {Promise<object>} - Result with download URL
 */
export const uploadImage = async (file, path) => {
  try {
    const storageRef = ref(storage, path)
    const uploadTask = uploadBytesResumable(storageRef, file)

    return new Promise((resolve, reject) => {
      uploadTask.on(
        'state_changed',
        (snapshot) => {
          // Track upload progress if needed
          const progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100
        },
        (error) => {
          reject({
            success: false,
            error: error.message
          })
        },
        async () => {
          const downloadURL = await getDownloadURL(uploadTask.snapshot.ref)
          resolve({
            success: true,
            url: downloadURL
          })
        }
      )
    })
  } catch (error) {
    return {
      success: false,
      error: error.message
    }
  }
}

// ============ FAVORITE SERVICES ============

/**
 * Add a restaurant to user's favorites
 * @param {string} userId - User ID
 * @param {string} restaurantId - Restaurant ID
 * @returns {Promise<object>} - Result
 */
export const addToFavorites = async (userId, restaurantId) => {
  try {
    const userQuery = query(collection(db, 'users'), where('uid', '==', userId))
    const userSnapshot = await getDocs(userQuery)

    if (!userSnapshot.empty) {
      const userDoc = userSnapshot.docs[0]
      const userData = userDoc.data()
      const favorites = userData.favoriteRestaurants || []

      if (!favorites.includes(restaurantId)) {
        favorites.push(restaurantId)
      }

      // Update the user document
      await addDoc(collection(db, 'users'), {
        ...userData,
        favoriteRestaurants: favorites,
        updatedAt: serverTimestamp()
      })

      return { success: true }
    }

    return { success: false, error: 'User not found' }
  } catch (error) {
    return {
      success: false,
      error: error.message
    }
  }
}

/**
 * Remove a restaurant from user's favorites
 * @param {string} userId - User ID
 * @param {string} restaurantId - Restaurant ID
 * @returns {Promise<object>} - Result
 */
export const removeFromFavorites = async (userId, restaurantId) => {
  try {
    const userQuery = query(collection(db, 'users'), where('uid', '==', userId))
    const userSnapshot = await getDocs(userQuery)

    if (!userSnapshot.empty) {
      const userDoc = userSnapshot.docs[0]
      const userData = userDoc.data()
      const favorites = userData.favoriteRestaurants || []

      const updatedFavorites = favorites.filter(id => id !== restaurantId)

      await addDoc(collection(db, 'users'), {
        ...userData,
        favoriteRestaurants: updatedFavorites,
        updatedAt: serverTimestamp()
      })

      return { success: true }
    }

    return { success: false, error: 'User not found' }
  } catch (error) {
    return {
      success: false,
      error: error.message
    }
  }
}

// Export all services
export default {
  registerUser,
  loginUser,
  logoutUser,
  onAuthChange,
  getCurrentUser,
  registerRestaurant,
  getAllRestaurants,
  getRestaurantById,
  getRestaurantsByOwner,
  addDish,
  getDishesByRestaurant,
  addReview,
  getReviewsByRestaurant,
  uploadImage,
  addToFavorites,
  removeFromFavorites
}
