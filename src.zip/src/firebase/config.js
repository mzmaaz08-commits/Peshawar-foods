import { initializeApp } from 'firebase/app'
import { getFirestore } from 'firebase/firestore'
import { getAuth } from 'firebase/auth'
import { getStorage } from 'firebase/storage'

// Firebase configuration
// IMPORTANT: Replace these placeholder values with your actual Firebase project credentials
// Follow the setup guide in FIREBASE_SETUP.md to get your config
const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY || "YOUR_API_KEY",
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN || "YOUR_PROJECT.firebaseapp.com",
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID || "YOUR_PROJECT_ID",
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET || "YOUR_PROJECT.appspot.com",
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID || "YOUR_SENDER_ID",
  appId: import.meta.env.VITE_FIREBASE_APP_ID || "YOUR_APP_ID"
}

// Check if Firebase config has placeholder values
const hasValidConfig = () => {
  return firebaseConfig.apiKey !== "YOUR_API_KEY" &&
         firebaseConfig.authDomain !== "YOUR_PROJECT.firebaseapp.com" &&
         firebaseConfig.projectId !== "YOUR_PROJECT_ID"
}

// Initialize Firebase
let app, db, auth, storage

try {
  if (hasValidConfig()) {
    app = initializeApp(firebaseConfig)
    db = getFirestore(app)
    auth = getAuth(app)
    storage = getStorage(app)
    console.log('Firebase initialized successfully')
  } else {
    console.warn('Firebase config has placeholder values. Please update src/firebase/config.js with your actual Firebase credentials. See FIREBASE_SETUP.md for instructions.')
  }
} catch (error) {
  console.error('Firebase initialization error:', error)
}

export { db, auth, storage, hasValidConfig }
