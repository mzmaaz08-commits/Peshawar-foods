import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import { AuthProvider } from './contexts/AuthContext'
import Navbar from './components/Navbar'
import Home from './pages/Home'
import RestaurantList from './pages/RestaurantList'
import RestaurantDetail from './pages/RestaurantDetail'
import OwnerDashboard from './pages/OwnerDashboard'
import Login from './pages/Login'
import Register from './pages/Register'
import RestaurantRegistration from './pages/RestaurantRegistration'

function App() {
  return (
    <AuthProvider>
      <Router>
        <div className="min-h-screen bg-light">
          <Navbar />
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/restaurants" element={<RestaurantList />} />
            <Route path="/restaurant/:id" element={<RestaurantDetail />} />
            <Route path="/dashboard" element={<OwnerDashboard />} />
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />
            <Route path="/register-restaurant" element={<RestaurantRegistration />} />
          </Routes>
        </div>
      </Router>
    </AuthProvider>
  )
}

export default App
