import { Link, useNavigate } from 'react-router-dom'
import { motion } from 'framer-motion'
import { Menu, X, MapPin, Utensils, LogOut } from 'lucide-react'
import { useState } from 'react'
import { useAuth } from '../contexts/AuthContext'

const Navbar = () => {
  const navigate = useNavigate()
  const [isOpen, setIsOpen] = useState(false)
  const { user, logout, isAuthenticated } = useAuth()

  const handleLogout = async () => {
    await logout()
    navigate('/')
  }

  return (
    <motion.nav
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      className="bg-white shadow-lg sticky top-0 z-50"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <Link to="/" className="flex items-center space-x-2">
            <Utensils className="w-8 h-8 text-primary" />
            <span className="text-xl font-bold text-gray-900">Peshawar Eats</span>
          </Link>

          <div className="hidden md:flex items-center space-x-8">
            <Link to="/" className="text-gray-700 hover:text-primary transition-colors">Home</Link>
            <Link to="/restaurants" className="text-gray-700 hover:text-primary transition-colors">Restaurants</Link>
            <Link to="/register-restaurant" className="text-gray-700 hover:text-primary transition-colors">Register Restaurant</Link>
            {isAuthenticated ? (
              <>
                <Link to="/dashboard" className="text-gray-700 hover:text-primary transition-colors">Dashboard</Link>
                <button
                  onClick={handleLogout}
                  className="flex items-center text-gray-700 hover:text-primary transition-colors"
                >
                  <LogOut className="w-4 h-4 mr-1" />
                  Logout
                </button>
              </>
            ) : (
              <Link to="/login" className="btn-primary">Login</Link>
            )}
          </div>

          <button
            className="md:hidden"
            onClick={() => setIsOpen(!isOpen)}
          >
            {isOpen ? <X /> : <Menu />}
          </button>
        </div>
      </div>

      {isOpen && (
        <motion.div
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: 'auto' }}
          className="md:hidden bg-white border-t"
        >
          <div className="px-4 py-4 space-y-3">
            <Link to="/" className="block text-gray-700 hover:text-primary">Home</Link>
            <Link to="/restaurants" className="block text-gray-700 hover:text-primary">Restaurants</Link>
            <Link to="/register-restaurant" className="block text-gray-700 hover:text-primary">Register Restaurant</Link>
            {isAuthenticated ? (
              <>
                <Link to="/dashboard" className="block text-gray-700 hover:text-primary">Dashboard</Link>
                <button
                  onClick={handleLogout}
                  className="block w-full text-left text-gray-700 hover:text-primary"
                >
                  <LogOut className="w-4 h-4 inline mr-1" />
                  Logout
                </button>
              </>
            ) : (
              <Link to="/login" className="block btn-primary text-center">Login</Link>
            )}
          </div>
        </motion.div>
      )}
    </motion.nav>
  )
}

export default Navbar
