import { motion } from 'framer-motion'
import { Link, useNavigate } from 'react-router-dom'
import { MapPin, Phone, Mail, Clock, Utensils, Upload, ArrowLeft, AlertCircle, CheckCircle } from 'lucide-react'
import { useState, useRef } from 'react'
import { registerRestaurant, uploadImage, getCurrentUser } from '../firebase/services'

const RestaurantRegistration = () => {
  const navigate = useNavigate()
  const fileInputRef = useRef(null)
  const [step, setStep] = useState(1)
  const [formData, setFormData] = useState({
    restaurantName: '',
    cuisine: '',
    address: '',
    phone: '',
    email: '',
    openingHours: '',
    priceRange: '',
    description: '',
    specialDish: '',
    specialDishPrice: ''
  })
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState('')
  const [success, setSuccess] = useState('')
  const [imageFile, setImageFile] = useState(null)
  const [imagePreview, setImagePreview] = useState('')

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    })
    if (error) setError('')
  }

  const handleImageChange = (e) => {
    const file = e.target.files[0]
    if (file) {
      setImageFile(file)
      const reader = new FileReader()
      reader.onloadend = () => {
        setImagePreview(reader.result)
      }
      reader.readAsDataURL(file)
    }
  }

  const handleImageUpload = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click()
    }
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setIsLoading(true)
    setError('')
    setSuccess('')

    // Check if user is logged in
    const currentUser = getCurrentUser()
    if (!currentUser) {
      setError('Please log in to register a restaurant')
      setIsLoading(false)
      return
    }

    try {
      let imageUrl = ''

      // Upload image if selected
      if (imageFile) {
        const uploadResult = await uploadImage(
          imageFile,
          `restaurants/${currentUser.uid}/${Date.now()}_${imageFile.name}`
        )

        if (uploadResult.success) {
          imageUrl = uploadResult.url
        } else {
          setError('Failed to upload image: ' + uploadResult.error)
          setIsLoading(false)
          return
        }
      }

      // Prepare restaurant data
      const restaurantData = {
        name: formData.restaurantName,
        cuisine: formData.cuisine,
        description: formData.description,
        address: formData.address,
        phone: formData.phone,
        email: formData.email,
        openingHours: formData.openingHours,
        priceRange: formData.priceRange,
        specialDish: formData.specialDish,
        specialDishPrice: formData.specialDishPrice,
        image: imageUrl
      }

      // Register restaurant in Firestore
      const result = await registerRestaurant(restaurantData, currentUser.uid)

      if (result.success) {
        setSuccess('Restaurant registered successfully!')
        // Redirect to dashboard after a short delay
        setTimeout(() => {
          navigate('/dashboard')
        }, 2000)
      } else {
        setError(result.error || 'Failed to register restaurant')
      }
    } catch (err) {
      setError('An unexpected error occurred: ' + err.message)
    }

    setIsLoading(false)
  }

  return (
    <div className="min-h-screen bg-light py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <Link to="/" className="inline-flex items-center text-gray-600 hover:text-primary mb-6">
          <ArrowLeft className="w-4 h-4 mr-2" /> Back to Home
        </Link>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-2xl shadow-2xl p-8"
        >
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold mb-2">Register Your Restaurant</h1>
            <p className="text-gray-600">Join Peshawar's premier dining platform</p>
          </div>

          {/* Progress Steps */}
          <div className="flex justify-between mb-8">
            {[1, 2, 3].map((stepNum) => (
              <div key={stepNum} className="flex items-center">
                <div className={`w-10 h-10 rounded-full flex items-center justify-center font-semibold ${
                  step >= stepNum ? 'bg-primary text-white' : 'bg-gray-200 text-gray-600'
                }`}>
                  {stepNum}
                </div>
                {stepNum < 3 && (
                  <div className={`w-24 h-1 mx-2 ${step > stepNum ? 'bg-primary' : 'bg-gray-200'}`}></div>
                )}
              </div>
            ))}
          </div>

          {/* Error Message */}
          {error && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg mb-6 flex items-center"
            >
              <AlertCircle className="w-5 h-5 mr-2 flex-shrink-0" />
              <span className="text-sm">{error}</span>
            </motion.div>
          )}

          {/* Success Message */}
          {success && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-lg mb-6 flex items-center"
            >
              <CheckCircle className="w-5 h-5 mr-2 flex-shrink-0" />
              <span className="text-sm">{success}</span>
            </motion.div>
          )}

          <form onSubmit={handleSubmit}>
            {/* Step 1: Basic Information */}
            {step === 1 && (
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                className="space-y-6"
              >
                <div>
                  <label className="block text-sm font-semibold mb-2">Restaurant Name *</label>
                  <input
                    type="text"
                    name="restaurantName"
                    value={formData.restaurantName}
                    onChange={handleChange}
                    placeholder="e.g., Charsi Tikka"
                    className="input-field"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-semibold mb-2">Cuisine Type *</label>
                  <select
                    name="cuisine"
                    value={formData.cuisine}
                    onChange={handleChange}
                    className="input-field"
                    required
                  >
                    <option value="">Select cuisine type</option>
                    <option value="Pakistani">Pakistani</option>
                    <option value="Afghan">Afghan</option>
                    <option value="Chinese">Chinese</option>
                    <option value="Fast Food">Fast Food</option>
                    <option value="Traditional">Traditional</option>
                    <option value="Continental">Continental</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-semibold mb-2">Price Range *</label>
                  <select
                    name="priceRange"
                    value={formData.priceRange}
                    onChange={handleChange}
                    className="input-field"
                    required
                  >
                    <option value="">Select price range</option>
                    <option value="$">$ (Budget-friendly)</option>
                    <option value="$$">$$ (Moderate)</option>
                    <option value="$$$">$$$ (Expensive)</option>
                    <option value="$$$$">$$$$ (Fine Dining)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-semibold mb-2">Description *</label>
                  <textarea
                    name="description"
                    value={formData.description}
                    onChange={handleChange}
                    placeholder="Tell us about your restaurant..."
                    rows="4"
                    className="input-field"
                    required
                  />
                </div>

                <button
                  type="button"
                  onClick={() => setStep(2)}
                  className="btn-primary w-full"
                >
                  Next Step
                </button>
              </motion.div>
            )}

            {/* Step 2: Contact & Location */}
            {step === 2 && (
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                className="space-y-6"
              >
                <div>
                  <label className="block text-sm font-semibold mb-2">Address *</label>
                  <div className="relative">
                    <MapPin className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400" />
                    <input
                      type="text"
                      name="address"
                      value={formData.address}
                      onChange={handleChange}
                      placeholder="Full address in Peshawar"
                      className="input-field pl-12"
                      required
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-semibold mb-2">Phone Number *</label>
                  <div className="relative">
                    <Phone className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400" />
                    <input
                      type="tel"
                      name="phone"
                      value={formData.phone}
                      onChange={handleChange}
                      placeholder="+92 300 1234567"
                      className="input-field pl-12"
                      required
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-semibold mb-2">Email *</label>
                  <div className="relative">
                    <Mail className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400" />
                    <input
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      placeholder="restaurant@email.com"
                      className="input-field pl-12"
                      required
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-semibold mb-2">Opening Hours *</label>
                  <div className="relative">
                    <Clock className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400" />
                    <input
                      type="text"
                      name="openingHours"
                      value={formData.openingHours}
                      onChange={handleChange}
                      placeholder="e.g., 11:00 AM - 11:00 PM"
                      className="input-field pl-12"
                      required
                    />
                  </div>
                </div>

                <div className="flex gap-4">
                  <button
                    type="button"
                    onClick={() => setStep(1)}
                    className="btn-secondary flex-1"
                  >
                    Previous
                  </button>
                  <button
                    type="button"
                    onClick={() => setStep(3)}
                    className="btn-primary flex-1"
                  >
                    Next Step
                  </button>
                </div>
              </motion.div>
            )}

            {/* Step 3: Special Dish & Images */}
            {step === 3 && (
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                className="space-y-6"
              >
                <div>
                  <label className="block text-sm font-semibold mb-2">Special Dish *</label>
                  <div className="relative">
                    <Utensils className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400" />
                    <input
                      type="text"
                      name="specialDish"
                      value={formData.specialDish}
                      onChange={handleChange}
                      placeholder="e.g., Charsi Tikka"
                      className="input-field pl-12"
                      required
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-semibold mb-2">Special Dish Price *</label>
                  <input
                    type="text"
                    name="specialDishPrice"
                    value={formData.specialDishPrice}
                    onChange={handleChange}
                    placeholder="e.g., Rs. 800"
                    className="input-field"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-semibold mb-2">Restaurant Image</label>
                  <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
                    {imagePreview ? (
                      <div className="mb-4">
                        <img
                          src={imagePreview}
                          alt="Preview"
                          className="w-32 h-32 object-cover rounded-lg mx-auto mb-2"
                        />
                        <p className="text-sm text-gray-500">Image ready to upload</p>
                      </div>
                    ) : (
                      <>
                        <Upload className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                        <p className="text-gray-600 mb-2">Drag and drop or click to upload</p>
                      </>
                    )}
                    <input
                      type="file"
                      accept="image/*"
                      ref={fileInputRef}
                      onChange={handleImageChange}
                      className="hidden"
                    />
                    <button
                      type="button"
                      className="btn-secondary"
                      onClick={handleImageUpload}
                    >
                      Choose File
                    </button>
                  </div>
                </div>

                <div className="flex gap-4">
                  <button
                    type="button"
                    onClick={() => setStep(2)}
                    className="btn-secondary flex-1"
                  >
                    Previous
                  </button>
                  <button
                    type="submit"
                    disabled={isLoading}
                    className="btn-primary flex-1 flex items-center justify-center"
                  >
                    {isLoading ? (
                      <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                    ) : null}
                    {isLoading ? 'Submitting...' : 'Submit Registration'}
                  </button>
                </div>
              </motion.div>
            )}
          </form>

          <div className="mt-6 text-center text-sm text-gray-500">
            <p>Already have an account? <Link to="/dashboard" className="text-primary hover:underline">Access Dashboard</Link></p>
          </div>
        </motion.div>
      </div>
    </div>
  )
}

export default RestaurantRegistration
