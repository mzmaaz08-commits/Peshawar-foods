import { motion } from 'framer-motion'
import { Link } from 'react-router-dom'
import { 
  LayoutDashboard, 
  Utensils, 
  Plus, 
  Edit, 
  Trash2, 
  Eye, 
  TrendingUp,
  Users,
  Star,
  Clock,
  LogOut,
  Settings,
  Image as ImageIcon
} from 'lucide-react'
import { useState } from 'react'

const OwnerDashboard = () => {
  const [activeTab, setActiveTab] = useState('overview')
  const [showAddDish, setShowAddDish] = useState(false)

  const restaurantData = {
    name: "Charsi Tikka",
    image: "https://images.unsplash.com/photo-1555939594-58d7cb561ad1?w=400",
    rating: 4.8,
    reviews: 567,
    views: 12450,
    orders: 234
  }

  const dishes = [
    { id: 1, name: "Charsi Tikka", price: "Rs. 800", category: "BBQ", available: true },
    { id: 2, name: "Kabuli Pulao", price: "Rs. 600", category: "Rice", available: true },
    { id: 3, name: "Mutton Karahi", price: "Rs. 1200", category: "Curry", available: false },
    { id: 4, name: "Chicken Biryani", price: "Rs. 450", category: "Rice", available: true }
  ]

  const tabs = [
    { id: 'overview', label: 'Overview', icon: LayoutDashboard },
    { id: 'dishes', label: 'Menu Management', icon: Utensils },
    { id: 'orders', label: 'Orders', icon: TrendingUp },
    { id: 'reviews', label: 'Reviews', icon: Star },
    { id: 'settings', label: 'Settings', icon: Settings }
  ]

  return (
    <div className="min-h-screen bg-light">
      {/* Header */}
      <header className="bg-white shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 bg-gradient-to-br from-primary to-orange-500 rounded-full flex items-center justify-center text-white font-bold">
                CT
              </div>
              <div>
                <h1 className="text-xl font-bold">{restaurantData.name}</h1>
                <p className="text-gray-500 text-sm">Owner Dashboard</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <Link to="/" className="text-gray-600 hover:text-primary">
                <Eye className="w-5 h-5" />
              </Link>
              <button className="text-gray-600 hover:text-red-500">
                <LogOut className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Sidebar */}
          <div className="lg:w-64">
            <div className="bg-white rounded-xl shadow-lg p-4 sticky top-24">
              <nav className="space-y-2">
                {tabs.map((tab) => (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg transition-all ${
                      activeTab === tab.id
                        ? 'bg-primary text-white'
                        : 'text-gray-700 hover:bg-gray-100'
                    }`}
                  >
                    <tab.icon className="w-5 h-5" />
                    <span>{tab.label}</span>
                  </button>
                ))}
              </nav>
            </div>
          </div>

          {/* Main Content */}
          <div className="flex-1">
            {/* Overview Tab */}
            {activeTab === 'overview' && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="space-y-6"
              >
                <h2 className="text-2xl font-bold">Dashboard Overview</h2>
                
                {/* Stats Cards */}
                <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
                  {[
                    { icon: Users, label: 'Total Views', value: restaurantData.views.toLocaleString(), color: 'bg-blue-500' },
                    { icon: TrendingUp, label: 'Orders', value: restaurantData.orders, color: 'bg-green-500' },
                    { icon: Star, label: 'Rating', value: restaurantData.rating, color: 'bg-yellow-500' },
                    { icon: Clock, label: 'Reviews', value: restaurantData.reviews, color: 'bg-purple-500' }
                  ].map((stat, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, scale: 0.9 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ delay: index * 0.1 }}
                      className="bg-white rounded-xl p-6 shadow-lg"
                    >
                      <div className={`w-12 h-12 ${stat.color} rounded-lg flex items-center justify-center mb-4`}>
                        <stat.icon className="w-6 h-6 text-white" />
                      </div>
                      <p className="text-gray-500 text-sm">{stat.label}</p>
                      <p className="text-2xl font-bold">{stat.value}</p>
                    </motion.div>
                  ))}
                </div>

                {/* Recent Activity */}
                <div className="bg-white rounded-xl shadow-lg p-6">
                  <h3 className="text-lg font-bold mb-4">Recent Activity</h3>
                  <div className="space-y-4">
                    {[
                      { action: 'New order received', time: '2 minutes ago', type: 'order' },
                      { action: 'New review: 5 stars', time: '15 minutes ago', type: 'review' },
                      { action: 'Menu item updated', time: '1 hour ago', type: 'update' },
                      { action: 'Profile viewed by 12 users', time: '2 hours ago', type: 'view' }
                    ].map((activity, index) => (
                      <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div className="flex items-center space-x-3">
                          <div className={`w-2 h-2 rounded-full ${
                            activity.type === 'order' ? 'bg-green-500' :
                            activity.type === 'review' ? 'bg-yellow-500' :
                            activity.type === 'update' ? 'bg-blue-500' : 'bg-purple-500'
                          }`}></div>
                          <span>{activity.action}</span>
                        </div>
                        <span className="text-gray-500 text-sm">{activity.time}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </motion.div>
            )}

            {/* Dishes Tab */}
            {activeTab === 'dishes' && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="space-y-6"
              >
                <div className="flex justify-between items-center">
                  <h2 className="text-2xl font-bold">Menu Management</h2>
                  <button
                    onClick={() => setShowAddDish(true)}
                    className="btn-primary flex items-center"
                  >
                    <Plus className="w-5 h-5 mr-2" /> Add Dish
                  </button>
                </div>

                <div className="bg-white rounded-xl shadow-lg overflow-hidden">
                  <table className="w-full">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Dish Name</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Category</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Price</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                      {dishes.map((dish) => (
                        <tr key={dish.id} className="hover:bg-gray-50">
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="flex items-center">
                              <div className="w-10 h-10 bg-gray-200 rounded-lg flex items-center justify-center mr-3">
                                <Utensils className="w-5 h-5 text-gray-400" />
                              </div>
                              <span className="font-medium">{dish.name}</span>
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-gray-500">{dish.category}</td>
                          <td className="px-6 py-4 whitespace-nowrap font-semibold">{dish.price}</td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
                              dish.available ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                            }`}>
                              {dish.available ? 'Available' : 'Unavailable'}
                            </span>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="flex space-x-2">
                              <button className="text-blue-600 hover:text-blue-800">
                                <Edit className="w-5 h-5" />
                              </button>
                              <button className="text-red-600 hover:text-red-800">
                                <Trash2 className="w-5 h-5" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {/* Add Dish Modal */}
                {showAddDish && (
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50"
                  >
                    <motion.div
                      initial={{ scale: 0.9 }}
                      animate={{ scale: 1 }}
                      className="bg-white rounded-xl p-6 w-full max-w-md"
                    >
                      <h3 className="text-xl font-bold mb-4">Add New Dish</h3>
                      <div className="space-y-4">
                        <div>
                          <label className="block text-sm font-semibold mb-2">Dish Name</label>
                          <input type="text" className="input-field" placeholder="e.g., Chicken Karahi" />
                        </div>
                        <div>
                          <label className="block text-sm font-semibold mb-2">Category</label>
                          <select className="input-field">
                            <option>BBQ</option>
                            <option>Curry</option>
                            <option>Rice</option>
                            <option>Bread</option>
                          </select>
                        </div>
                        <div>
                          <label className="block text-sm font-semibold mb-2">Price</label>
                          <input type="text" className="input-field" placeholder="e.g., Rs. 800" />
                        </div>
                        <div>
                          <label className="block text-sm font-semibold mb-2">Image</label>
                          <div className="border-2 border-dashed border-gray-300 rounded-lg p-4 text-center">
                            <ImageIcon className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                            <p className="text-sm text-gray-500">Upload dish image</p>
                          </div>
                        </div>
                        <div className="flex gap-4">
                          <button
                            onClick={() => setShowAddDish(false)}
                            className="btn-secondary flex-1"
                          >
                            Cancel
                          </button>
                          <button className="btn-primary flex-1">Add Dish</button>
                        </div>
                      </div>
                    </motion.div>
                  </motion.div>
                )}
              </motion.div>
            )}

            {/* Orders Tab */}
            {activeTab === 'orders' && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="space-y-6"
              >
                <h2 className="text-2xl font-bold">Orders</h2>
                <div className="bg-white rounded-xl shadow-lg p-6">
                  <p className="text-gray-500 text-center py-8">Order management coming soon...</p>
                </div>
              </motion.div>
            )}

            {/* Reviews Tab */}
            {activeTab === 'reviews' && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="space-y-6"
              >
                <h2 className="text-2xl font-bold">Customer Reviews</h2>
                <div className="space-y-4">
                  {[
                    { name: "Ahmed Khan", rating: 5, comment: "Amazing food! Best Charsi Tikka in Peshawar.", date: "2 days ago" },
                    { name: "Sara Ali", rating: 4, comment: "Great taste, friendly staff. Will visit again!", date: "1 week ago" },
                    { name: "Usman Malik", rating: 5, comment: "Authentic Peshawari flavors. Highly recommended!", date: "1 week ago" }
                  ].map((review, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.1 }}
                      className="bg-white rounded-xl p-6 shadow-lg"
                    >
                      <div className="flex justify-between items-start mb-3">
                        <div>
                          <h4 className="font-bold">{review.name}</h4>
                          <div className="flex items-center">
                            {[...Array(5)].map((_, i) => (
                              <Star
                                key={i}
                                className={`w-4 h-4 ${
                                  i < review.rating ? 'text-yellow-400 fill-current' : 'text-gray-300'
                                }`}
                              />
                            ))}
                          </div>
                        </div>
                        <span className="text-gray-500 text-sm">{review.date}</span>
                      </div>
                      <p className="text-gray-600">{review.comment}</p>
                    </motion.div>
                  ))}
                </div>
              </motion.div>
            )}

            {/* Settings Tab */}
            {activeTab === 'settings' && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="space-y-6"
              >
                <h2 className="text-2xl font-bold">Restaurant Settings</h2>
                <div className="bg-white rounded-xl shadow-lg p-6">
                  <div className="space-y-6">
                    <div>
                      <label className="block text-sm font-semibold mb-2">Restaurant Name</label>
                      <input type="text" defaultValue={restaurantData.name} className="input-field" />
                    </div>
                    <div>
                      <label className="block text-sm font-semibold mb-2">Opening Hours</label>
                      <input type="text" defaultValue="11:00 AM - 11:00 PM" className="input-field" />
                    </div>
                    <div>
                      <label className="block text-sm font-semibold mb-2">Contact Number</label>
                      <input type="tel" defaultValue="+92 300 1234567" className="input-field" />
                    </div>
                    <button className="btn-primary">Save Changes</button>
                  </div>
                </div>
              </motion.div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}

export default OwnerDashboard
