import { motion } from 'framer-motion'
import { Link } from 'react-router-dom'
import { Search, MapPin, Star, Filter, Clock, DollarSign } from 'lucide-react'
import { useState } from 'react'

const RestaurantList = () => {
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedCuisine, setSelectedCuisine] = useState('all')
  const [priceRange, setPriceRange] = useState('all')

  const cuisines = ['All', 'Pakistani', 'Afghan', 'Chinese', 'Fast Food', 'Traditional']
  const priceRanges = ['All', '$', '$$', '$$$', '$$$$']

  const restaurants = [
    {
      id: 1,
      name: "Kabul Restaurant",
      image: "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=500",
      cuisine: "Afghan",
      rating: 4.5,
      reviews: 234,
      location: "University Road, Peshawar",
      priceRange: "$$",
      isOpen: true,
      specialDish: "Kabuli Pulao"
    },
    {
      id: 2,
      name: "Charsi Tikka",
      image: "https://images.unsplash.com/photo-1555939594-58d7cb561ad1?w=500",
      cuisine: "Pakistani",
      rating: 4.8,
      reviews: 567,
      location: "Namak Mandi, Peshawar",
      priceRange: "$$",
      isOpen: true,
      specialDish: "Charsi Tikka"
    },
    {
      id: 3,
      name: "Dragon Palace",
      image: "https://images.unsplash.com/photo-1552566626-52f8b828add9?w=500",
      cuisine: "Chinese",
      rating: 4.2,
      reviews: 189,
      location: "Hayatabad, Peshawar",
      priceRange: "$$$",
      isOpen: true,
      specialDish: "Kung Pao Chicken"
    },
    {
      id: 4,
      name: "Peshawar Karahi",
      image: "https://images.unsplash.com/photo-1585937421612-70a008356fbe?w=500",
      cuisine: "Traditional",
      rating: 4.6,
      reviews: 345,
      location: "Cantt, Peshawar",
      priceRange: "$$",
      isOpen: false,
      specialDish: "Mutton Karahi"
    },
    {
      id: 5,
      name: "Burger Hub",
      image: "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=500",
      cuisine: "Fast Food",
      rating: 4.3,
      reviews: 412,
      location: "University Town, Peshawar",
      priceRange: "$",
      isOpen: true,
      specialDish: "Classic Burger"
    },
    {
      id: 6,
      name: "Lahori Grill",
      image: "https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=500",
      cuisine: "Pakistani",
      rating: 4.7,
      reviews: 678,
      location: "Sadar, Peshawar",
      priceRange: "$$",
      isOpen: true,
      specialDish: "Chicken Biryani"
    }
  ]

  return (
    <div className="min-h-screen bg-light py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1 className="text-4xl font-bold mb-2">Restaurants in Peshawar</h1>
          <p className="text-gray-600">Discover the best dining experiences in the city</p>
        </motion.div>

        {/* Search and Filters */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-white rounded-xl shadow-lg p-6 mb-8"
        >
          <div className="flex flex-col lg:flex-row gap-4">
            {/* Search */}
            <div className="flex-1 relative">
              <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400" />
              <input
                type="text"
                placeholder="Search restaurants, dishes..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="input-field pl-12"
              />
            </div>

            {/* Cuisine Filter */}
            <div className="relative">
              <Filter className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400" />
              <select
                value={selectedCuisine}
                onChange={(e) => setSelectedCuisine(e.target.value)}
                className="input-field pl-12 appearance-none cursor-pointer"
              >
                {cuisines.map(cuisine => (
                  <option key={cuisine} value={cuisine.toLowerCase()}>
                    {cuisine}
                  </option>
                ))}
              </select>
            </div>

            {/* Price Filter */}
            <select
              value={priceRange}
              onChange={(e) => setPriceRange(e.target.value)}
              className="input-field appearance-none cursor-pointer"
            >
              {priceRanges.map(range => (
                <option key={range} value={range.toLowerCase()}>
                  {range === 'All' ? 'Price Range' : range}
                </option>
              ))}
            </select>
          </div>
        </motion.div>

        {/* Restaurant Grid */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.4 }}
          className="grid md:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          {restaurants.map((restaurant, index) => (
            <motion.div
              key={restaurant.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              whileHover={{ scale: 1.03 }}
              className="card cursor-pointer"
            >
              <Link to={`/restaurant/${restaurant.id}`}>
                <div className="relative h-48 overflow-hidden">
                  <img
                    src={restaurant.image}
                    alt={restaurant.name}
                    className="w-full h-full object-cover transition-transform duration-300 hover:scale-110"
                  />
                  <div className="absolute top-4 right-4 bg-white px-3 py-1 rounded-full text-sm font-semibold">
                    {restaurant.priceRange}
                  </div>
                  {restaurant.isOpen ? (
                    <div className="absolute top-4 left-4 bg-green-500 text-white px-3 py-1 rounded-full text-sm font-semibold flex items-center">
                      <Clock className="w-3 h-3 mr-1" /> Open
                    </div>
                  ) : (
                    <div className="absolute top-4 left-4 bg-red-500 text-white px-3 py-1 rounded-full text-sm font-semibold flex items-center">
                      <Clock className="w-3 h-3 mr-1" /> Closed
                    </div>
                  )}
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-bold mb-2">{restaurant.name}</h3>
                  <p className="text-primary font-semibold mb-2">{restaurant.specialDish}</p>
                  <div className="flex items-center text-gray-600 mb-3">
                    <MapPin className="w-4 h-4 mr-1" />
                    <span className="text-sm">{restaurant.location}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <Star className="w-4 h-4 text-yellow-400 fill-current" />
                      <span className="ml-1 font-semibold">{restaurant.rating}</span>
                      <span className="text-gray-500 ml-1">({restaurant.reviews})</span>
                    </div>
                    <span className="text-sm text-gray-500">{restaurant.cuisine}</span>
                  </div>
                </div>
              </Link>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </div>
  )
}

export default RestaurantList
