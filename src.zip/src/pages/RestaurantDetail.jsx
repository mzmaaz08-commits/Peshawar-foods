import { motion } from 'framer-motion'
import { useParams, Link } from 'react-router-dom'
import { MapPin, Star, Clock, Phone, Utensils, Heart, Share2, ArrowLeft } from 'lucide-react'
import { useState } from 'react'

const RestaurantDetail = () => {
  const { id } = useParams()
  const [isFavorite, setIsFavorite] = useState(false)

  const restaurant = {
    id: 1,
    name: "Charsi Tikka",
    image: "https://images.unsplash.com/photo-1555939594-58d7cb561ad1?w=800",
    cuisine: "Pakistani",
    rating: 4.8,
    reviews: 567,
    location: "Namak Mandi, Peshawar",
    phone: "+92 300 1234567",
    priceRange: "$$",
    isOpen: true,
    openingHours: "11:00 AM - 11:00 PM",
    description: "Experience the authentic taste of Peshawar with our famous Charsi Tikka. Known for our traditional cooking methods and secret spice blends, we've been serving the best BBQ in Peshawar for over 30 years.",
    specialDishes: [
      { name: "Charsi Tikka", price: "Rs. 800", image: "https://images.unsplash.com/photo-1555939594-58d7cb561ad1?w=300" },
      { name: "Kabuli Pulao", price: "Rs. 600", image: "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=300" },
      { name: "Mutton Karahi", price: "Rs. 1200", image: "https://images.unsplash.com/photo-1585937421612-70a008356fbe?w=300" },
      { name: "Chicken Biryani", price: "Rs. 450", image: "https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=300" }
    ]
  }

  return (
    <div className="min-h-screen bg-light">
      {/* Hero Image */}
      <div className="relative h-96">
        <img
          src={restaurant.image}
          alt={restaurant.name}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent"></div>
        <div className="absolute bottom-0 left-0 right-0 p-8">
          <Link to="/restaurants" className="text-white mb-4 inline-flex items-center hover:text-orange-300">
            <ArrowLeft className="w-5 h-5 mr-2" /> Back to Restaurants
          </Link>
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-4xl md:text-5xl font-bold text-white mb-2"
          >
            {restaurant.name}
          </motion.h1>
          <p className="text-white/80 text-lg">{restaurant.cuisine} Cuisine</p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Info Cards */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="grid md:grid-cols-2 gap-4"
            >
              <div className="bg-white rounded-xl p-6 shadow-lg">
                <div className="flex items-center mb-2">
                  <Star className="w-5 h-5 text-yellow-400 fill-current mr-2" />
                  <span className="text-2xl font-bold">{restaurant.rating}</span>
                  <span className="text-gray-500 ml-2">({restaurant.reviews} reviews)</span>
                </div>
                <p className="text-gray-600">Excellent rating</p>
              </div>

              <div className="bg-white rounded-xl p-6 shadow-lg">
                <div className="flex items-center mb-2">
                  <Clock className="w-5 h-5 text-primary mr-2" />
                  <span className="font-semibold">{restaurant.isOpen ? 'Open Now' : 'Closed'}</span>
                </div>
                <p className="text-gray-600">{restaurant.openingHours}</p>
              </div>

              <div className="bg-white rounded-xl p-6 shadow-lg">
                <div className="flex items-center mb-2">
                  <MapPin className="w-5 h-5 text-primary mr-2" />
                  <span className="font-semibold">Location</span>
                </div>
                <p className="text-gray-600">{restaurant.location}</p>
              </div>

              <div className="bg-white rounded-xl p-6 shadow-lg">
                <div className="flex items-center mb-2">
                  <Phone className="w-5 h-5 text-primary mr-2" />
                  <span className="font-semibold">Contact</span>
                </div>
                <p className="text-gray-600">{restaurant.phone}</p>
              </div>
            </motion.div>

            {/* Description */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="bg-white rounded-xl p-6 shadow-lg"
            >
              <h2 className="text-2xl font-bold mb-4">About</h2>
              <p className="text-gray-600 leading-relaxed">{restaurant.description}</p>
            </motion.div>

            {/* Special Dishes */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
            >
              <h2 className="text-2xl font-bold mb-4">Special Dishes</h2>
              <div className="grid md:grid-cols-2 gap-4">
                {restaurant.specialDishes.map((dish, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: 0.4 + index * 0.1 }}
                    whileHover={{ scale: 1.05 }}
                    className="bg-white rounded-xl overflow-hidden shadow-lg cursor-pointer"
                  >
                    <img
                      src={dish.image}
                      alt={dish.name}
                      className="w-full h-40 object-cover"
                    />
                    <div className="p-4">
                      <h3 className="font-bold text-lg mb-1">{dish.name}</h3>
                      <p className="text-primary font-semibold">{dish.price}</p>
                    </div>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Actions */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="bg-white rounded-xl p-6 shadow-lg sticky top-24"
            >
              <div className="flex gap-3 mb-4">
                <button className="flex-1 btn-primary">
                  Reserve Table
                </button>
                <button
                  onClick={() => setIsFavorite(!isFavorite)}
                  className={`p-3 rounded-lg border-2 transition-all ${
                    isFavorite ? 'border-red-500 text-red-500' : 'border-gray-300 text-gray-600'
                  }`}
                >
                  <Heart className={isFavorite ? 'fill-current' : ''} />
                </button>
                <button className="p-3 rounded-lg border-2 border-gray-300 text-gray-600">
                  <Share2 />
                </button>
              </div>

              <div className="border-t pt-4">
                <h3 className="font-semibold mb-2">Price Range</h3>
                <p className="text-2xl font-bold text-primary">{restaurant.priceRange}</p>
                <p className="text-gray-500 text-sm">Moderate pricing</p>
              </div>

              <div className="border-t pt-4 mt-4">
                <h3 className="font-semibold mb-2">Cuisine Type</h3>
                <p className="text-gray-600">{restaurant.cuisine}</p>
              </div>
            </motion.div>

            {/* Map Placeholder */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2 }}
              className="bg-white rounded-xl p-6 shadow-lg"
            >
              <h3 className="font-semibold mb-4">Location</h3>
              <div className="bg-gray-200 rounded-lg h-48 flex items-center justify-center">
                <div className="text-center text-gray-500">
                  <MapPin className="w-8 h-8 mx-auto mb-2" />
                  <p>Map integration coming soon</p>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default RestaurantDetail
