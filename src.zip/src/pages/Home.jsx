import { motion } from 'framer-motion'
import { Link } from 'react-router-dom'
import { Search, MapPin, Star, ArrowRight, Utensils, Clock } from 'lucide-react'

const Home = () => {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-secondary to-dark text-white overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-20 left-20 w-72 h-72 bg-primary rounded-full filter blur-3xl animate-pulse"></div>
          <div className="absolute bottom-20 right-20 w-96 h-96 bg-accent rounded-full filter blur-3xl animate-pulse delay-1000"></div>
        </div>
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 md:py-32">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center"
          >
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="text-4xl md:text-6xl font-bold mb-6"
            >
              Discover Peshawar's Finest Cuisine
            </motion.h1>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
              className="text-xl md:text-2xl mb-8 text-gray-200"
            >
              Explore the best restaurants, traditional dishes, and culinary experiences in the heart of Peshawar
            </motion.p>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6 }}
              className="flex flex-col sm:flex-row gap-4 justify-center"
            >
              <Link to="/restaurants" className="btn-primary text-lg">
                Explore Restaurants
              </Link>
              <Link to="/register-restaurant" className="btn-secondary text-lg">
                Register Your Restaurant
              </Link>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* Search Section */}
      <section className="bg-white py-12 -mt-8 relative z-10">
        <div className="max-w-4xl mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="bg-white rounded-2xl shadow-2xl p-6"
          >
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1 relative">
                <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400" />
                <input
                  type="text"
                  placeholder="Search restaurants, dishes..."
                  className="input-field pl-12"
                />
              </div>
              <button className="btn-primary whitespace-nowrap">
                Search
              </button>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-light">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Why Choose Peshawar Eats?</h2>
            <p className="text-gray-600 text-lg">Your gateway to authentic Peshawari cuisine</p>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                icon: <MapPin className="w-12 h-12 text-primary" />,
                title: "Local Favorites",
                description: "Discover hidden gems and popular local spots loved by residents"
              },
              {
                icon: <Star className="w-12 h-12 text-primary" />,
                title: "Verified Reviews",
                description: "Real reviews from food lovers to help you make the best choice"
              },
              {
                icon: <Clock className="w-12 h-12 text-primary" />,
                title: "Real-time Updates",
                description: "Current opening hours, special offers, and live availability"
              }
            ].map((feature, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.2 }}
                className="card p-8 text-center"
              >
                <div className="flex justify-center mb-4">{feature.icon}</div>
                <h3 className="text-xl font-bold mb-2">{feature.title}</h3>
                <p className="text-gray-600">{feature.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Restaurants Preview */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="flex justify-between items-center mb-12"
          >
            <div>
              <h2 className="text-3xl md:text-4xl font-bold mb-2">Featured Restaurants</h2>
              <p className="text-gray-600">Top-rated spots in Peshawar</p>
            </div>
            <Link to="/restaurants" className="flex items-center text-primary font-semibold hover:text-orange-600">
              View All <ArrowRight className="ml-2" />
            </Link>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-8">
            {[1, 2, 3].map((item) => (
              <motion.div
                key={item}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: item * 0.2 }}
                whileHover={{ scale: 1.05 }}
                className="card cursor-pointer"
              >
                <div className="h-48 bg-gradient-to-br from-primary to-accent"></div>
                <div className="p-6">
                  <h3 className="text-xl font-bold mb-2">Restaurant Name {item}</h3>
                  <div className="flex items-center text-gray-600 mb-2">
                    <MapPin className="w-4 h-4 mr-1" />
                    <span className="text-sm">Peshawar City</span>
                  </div>
                  <div className="flex items-center">
                    <Star className="w-4 h-4 text-yellow-400 fill-current" />
                    <span className="ml-1 font-semibold">4.5</span>
                    <span className="text-gray-500 ml-1">(120 reviews)</span>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-primary to-orange-500 text-white">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Restaurant Owner?</h2>
            <p className="text-xl mb-8 text-orange-100">
              Join our platform and reach thousands of food lovers in Peshawar
            </p>
            <Link to="/register-restaurant" className="bg-white text-primary font-semibold py-3 px-8 rounded-lg hover:bg-gray-100 transition-all duration-300 transform hover:scale-105 inline-block">
              Register Your Restaurant
            </Link>
          </motion.div>
        </div>
      </section>
    </div>
  )
}

export default Home
