import { createContext, useContext, useEffect, useState, useMemo } from 'react'
import { onAuthChange, logoutUser } from '../firebase/services'

const AuthContext = createContext()

export const useAuth = () => {
  const context = useContext(AuthContext)
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider')
  }
  return context
}

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const unsubscribe = onAuthChange((user) => {
      setUser(user)
      setLoading(false)
    })

    return () => unsubscribe()
  }, [])

  const logout = async () => {
    const result = await logoutUser()
    if (result.success) {
      setUser(null)
    }
    return result
  }

  const value = useMemo(() => ({
    user,
    loading,
    logout,
    isAuthenticated: !!user
  }), [user, loading])

  return (
    <AuthContext.Provider value={value}>
      {!loading && children}
    </AuthContext.Provider>
  )
}

export default AuthContext
